/**
 * Story state.
 */
function Story() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Story.prototype = proto;

Story.prototype.preload = function() {
	this.load.pack("level", "CrabMan/assets-pack.json");
};

Story.prototype.create = function() {
	var sprite = this.add.sprite(this.world.centerX, this.world.centerY,
			"C1S1");
	sprite.anchor.set(0.5, 0.5);
	this.input.onDown.add(this.startGame, this);
};

Story.prototype.Start = function() {
	this.game.state.start("Menu");
};