/**
 * Level state.
 */
function Level3() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Level3.prototype = proto;



Level3.prototype.create = function() {

	 
	 this.boom = this.add.audio("boomsound");
	 this.boom.allowMultiple=true;
	 
	 this.shoot = this.add.audio("laser");
	 this.shoot.allowMultiple=true;
	
	
	this.background = this.game.add.sprite(0,0,'bg6'); 
	
	Level3.prototype.onPlayerCollide = function(player,alien){
		life--;
		this.LifeText.text = ''+life;
		player.damage(1);
		alien.kill();
		player.canhit = false;
		player.alpha = 0.1;
		var tw = this.add.tween(player);
		tw.to({alpha:1},200, "Linear",true,0,5);
		tw.onComplete.addOnce(function(){this.alpha=1;this.canhit=true;}, player);
		return true;
		};
	life = 10;
	this.LifeTextText = this.add.text(this.world.centerX+85, 0, 'Life :', { fill: 'white' });
	this.LifeText = this.add.text(this.world.centerX + 145, 0, ''+life, { fill: 'white' });
	this.LifeText.z = 10;
	
	 this.game.score = 0;
	 this.gameover=false;
	 this.physics.startSystem(Phaser.Physics.ARCADE);
	 this.player = this.add.sprite(this.world.centerX,600,"ship1");
	 this.player.anchor.set(0.5,0.5);
	 this.player.animations.add("fly");
	 this.player.play("fly",12,true);
	 this.player.smoothed=false;
	 this.player.scale.set(3);
	 this.player.maxHealth = 10;
	 this.player.setHealth(10);
	 this.player.events.onKilled.addOnce(this.onPlayerKilled,this);
	 this.player.canhit = true;
	 this.physics.enable(this.player, Phaser.Physics.ARCADE);
	 this.player.body.collideWorldBounds = true;
	 this.player.body.allowGravity = false;
	 this.player.body.maxVelocity.setTo(500,500);
	 this.createAlien();
	 this.createWeapon();
	 this.scoreText = this.add.text(32, 0, ''+this.game.score, { fill: 'white' });
	 this.scoreText.z = 10;
	 this.input.keyboard.addKeyCapture([
	 Phaser.Keyboard.LEFT,
	 Phaser.Keyboard.RIGHT,
	 Phaser.Keyboard.UP,
	 Phaser.Keyboard.DOWN,
	 Phaser.Keyboard.SPACEBAR,
	 Phaser.Keyboard.X
	 ]);
	 
	 this.player.inputEnabled = true;
	 this.player.events.onInputDown.add(this.fireWeapon, this);
	 
	 


	 
};

Level3.prototype.onCollide = function(alien,bullet){
	alien.kill();
	bullet.kill();
	this.game.score++;
	this.scoreText.text = 'Score : ' + this.game.score;
	
	exp = this.add.sprite(alien.x, alien.y,"boom");
	exp.anchor.set(-1.0);
	exp.animations.add("all",null,12,false).play().killOnComplete=true;
	this.boom.play();
	};
	

	
	Level3.prototype.quitGame = function() {
		this.game.state.start("Level3Boss");
		};
		
		Level3.prototype.onPlayerKilled = function(){
			this.gameover=true;
			win = this.add.text(this.world.centerX,this.world.centerY,
			 "Fail !",{ fill: 'Blue'});
			win.anchor.set(0.5,0.5);
			win.scale.set(0.1);
			var tw = this.add.tween(win.scale);
			tw.to({x:2,y:2},1000, "Linear",true,0);
			delay = this.add.tween(win);
			delay.to({y:100},1000, "Linear",true,2000);
			tw.chain(delay);
			delay.onComplete.addOnce(this.quitGame6, this);
			
		};
		Level.prototype.quitGame6 = function() {
			this.game.state.start("Menu");
			};

			Level3.prototype.update = function() { };
			Level3.prototype.createAlien = function() { };
			Level3.prototype.createWeapon = function() { };
			Level3.prototype.fireWeapon = function() { };

			Level3.prototype.update = function(){
	if(this.gameover) return;
	 if(this.input.keyboard.isDown(Phaser.Keyboard.LEFT)){
	 this.player.body.acceleration.x = -10000;
	 }else if(this.input.keyboard.isDown(Phaser.Keyboard.RIGHT)){
	 this.player.body.acceleration.x = 10000;
	 }else{
	 this.player.body.velocity.setTo(0, 0);
	 this.player.body.acceleration.setTo(0, 0);
	 }
	 if(this.input.keyboard.isDown(Phaser.Keyboard.UP)){
		 this.player.body.acceleration.y = -800000;
		 }else if(this.input.keyboard.isDown(Phaser.Keyboard.DOWN)){
		 this.player.body.acceleration.y = 800000;
		 }
	 if(this.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)){
	 this.fireWeapon();
	 this.shoot.play();
	 }
	 if(this.input.keyboard.isDown(Phaser.Keyboard.X)){
		 this.fireWeapon();
		 this.shoot.play();
		 }
	 
	 this.aliens.forEachAlive(function(a){
	 if(a.y > this.world.height) a.y = -Math.random() * 300;
	 },this);

	 this.physics.arcade.collide(this.aliens,this.weapon1.bullets,this.onCollide,null,this);
	 this.physics.arcade.collide(this.aliens,this.weapon2.bullets,this.onCollide,null,this);
	 this.physics.arcade.collide(this.aliens,this.player,this.onPlayerCollide,null,this);
	 
	 if(this.player.canhit){
		 this.physics.arcade.collide(this.aliens,this.player,this.onPlayerCollide,null,this);
		 }
	
	 if(this.aliens.countLiving()==0 ){
	 this.gameover=true;
	 win = this.add.text(this.world.centerX,this.world.centerY,"Clear !",{fill:'red'});
	 win.anchor.set(0.5,0.5);
	 win.scale.set(10.1);
	 var tw = this.add.tween(win.scale);
	 tw.to({x:2,y:2},1000, "Expo",true,0);

	 delay = this.add.tween(win);
	 delay.to({y:100},1000, "Linear",true,2000);
	 tw.chain(delay);
	 delay.onComplete.addOnce(this.quitGame, this);
	 }
	};
	
	Level3.prototype.createWeapon = function() {
		this.weapon1 = this.add.weapon(5,"G1",10);
		this.weapon1.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
		this.weapon1.trackSprite(this.player,-30,-30);
		this.weapon1.bulletSpeed = 500;
		this.weapon1.fireAngle = 270;
		this.weapon1.rate = 400;
		this.weapon2 = this.add.weapon(5,"G1",10);
		this.weapon2.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
		this.weapon2.trackSprite(this.player,30,-30);
		this.weapon2.bulletSpeed = 500;
		this.weapon2.fireAngle = 270;
		this.weapon2.rate = 400;
		};
		
		Level3.prototype.fireWeapon = function(){
		this.weapon1.fire();
		this.weapon2.fire();
	};

	Level3.prototype.createAlien = function() {
		this.aliens = this.add.group(this.game.world,'Mon3',false,true,
		 Phaser.Physics.ARCADE);
		this.aliens.z = 1;
		for(i=0;i<100;i++){
		a = this.aliens.create(Math.random() * 1000,1000,"Mon3");
		a.animations.add("fly").play(12,true);
		a.anchor.set(-1.0);
		a.body.velocity.y = 150;
		tw = this.add.tween(a);
		var nx=300;
		var nt=300;
		tw.to({x:nx},10000, "Sine",false,0,Number.MAX_VALUE,true);
		if(Math.random()>0.5) a.body.angularVelocity = 0;
		
		else a.body.angularVelocity = 0;
	
		}
		};