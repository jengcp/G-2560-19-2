/**
 * Story state.
 */
function Cutscene1() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Cutscene1.prototype = proto;

Cutscene1.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Cutscene1.prototype.create = function() {
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
			"C1S1");
	this.sprite.anchor.set(0.5, 0.5);
	
	this.input.onDown.add(this.showS2, this);

};
Cutscene1.prototype.showS2 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C1S2");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS3, this);
};

Cutscene1.prototype.showS3 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C1S3");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS4, this);
};
Cutscene1.prototype.showS4 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C1S4");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.startGame, this);
};
Cutscene1.prototype.startGame = function() {
	this.game.state.start("Level");
};