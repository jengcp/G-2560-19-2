/**
 * Story state.
 */
function Cutscene3() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Cutscene3.prototype = proto;

Cutscene3.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Cutscene3.prototype.create = function() {
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
			"C3S1");
	this.sprite.anchor.set(0.5, 0.5);
	
	this.input.onDown.add(this.showS2, this);

};
Cutscene3.prototype.showS2 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C3S2");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS3, this);
};

Cutscene3.prototype.showS3 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C3S3");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS4, this);
};
Cutscene3.prototype.showS4 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C3S4");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS5, this);
};
Cutscene3.prototype.showS5 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C3S5");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.showS6, this);
};
Cutscene3.prototype.showS6 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C3S6");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.startGame, this);
};
Cutscene3.prototype.startGame = function() {
	this.game.state.start("Level3");
};