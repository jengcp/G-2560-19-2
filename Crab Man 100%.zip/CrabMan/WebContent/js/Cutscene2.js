/**
 * Story state.
 */
function Cutscene2() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Cutscene2.prototype = proto;

Cutscene2.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Cutscene2.prototype.create = function() {
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
			"C2S1");
	this.sprite.anchor.set(0.5, 0.5);
	
	this.input.onDown.add(this.showS2, this);

};
Cutscene2.prototype.showS2 = function() {
	this.sprite.kill();
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
	"C2S2");
    this.sprite.anchor.set(0.5, 0.5);	
    this.input.onDown.add(this.startGame, this);

};
Cutscene2.prototype.startGame = function() {
	this.game.state.start("Level2");
};