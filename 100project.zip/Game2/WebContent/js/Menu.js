/**
 * Menu state.
 */
function Menu() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Menu.prototype = proto;

Menu.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Menu.prototype.create = function() {
	this.music =this.add.sound("mus3",1,true);
	this.music.play();
	
	var cx=this.world.centerX;

	var mstart = this.add.sprite(cx+100,100,"mstart");
	var mstory = this.add.sprite(cx+100,100+40,"mstory");
	var mteam = this.add.sprite(cx+100,100+40*2,"mteam");
	
	var mute=this.add.sprite(cx+175,250+30*2,"mute");
	var notmute=this.add.sprite(cx+250,250+30*2,"notmute");
	
	
	var logo = this.add.sprite(this.world.centerX,-200,"logo");
	logo.width =320;
	logo.anchor.set(0.5,0);
	var twn =this.add.tween(logo);
	twn.to({y:-20},400,"Quad.easeInOut",true,0);
	
	mstart.anchor.set(0.25, 0.25);
	mstory.anchor.set(0.25, 0.25);
	mteam.anchor.set(0.25, 0.25);
	mute.anchor.set(0.25,0.25);
	notmute.anchor.set(0.25,0.25);
	
	mstart.inputEnabled = true;
	mstory.inputEnabled = true;
	mteam.inputEnabled = true;
	mute.inputEnabled = true;
	notmute.inputEnabled = true;
	
	
    mstart.events.onInputDown.add(this.startLevel, this);
    mstory.events.onInputDown.add(this.startStory, this);
    mteam.events.onInputDown.add(this.startTeam, this);
    mute.events.onInputDown.add(this.mute, this);
    notmute.events.onInputDown.add(this.notmute, this);
   
    
};

Menu.prototype.mute = function(){
	this.music.stop();	
};

Menu.prototype.notmute = function(){
	this.music.play();
};

Menu.prototype.startLevel = function(){
	this.game.state.start("Level");
	this.music.stop();
};
Menu.prototype.startStory = function(){
	this.game.state.start("Story");
	this.music.stop();
};
Menu.prototype.startTeam = function(){
	this.game.state.start("Team");
	this.music.stop();
}
