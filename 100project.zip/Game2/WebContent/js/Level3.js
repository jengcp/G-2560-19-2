/**
 * Level state.
 */
function Level3() {
	Phaser.State.call(this);
}
/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Level3.prototype = proto;
var count = 0;

Level3.prototype.create = function() {
	this.music = this.sound.add("HF", 1, true);
	this.music.play();
	this.game.score = 30;
	this.gameover = false;
	this.physics.startSystem(Phaser.Physics.ARCADE);

	// bg
	this.game.stage.backgroundColor = "#7c8b92";
	this.background = this.add.tileSprite(0, 0, this.game.width,
			this.game.height, 'map');
	this.midgroundImage = this.game.add.tileSprite(0, -15, 640, 360, 'map2');
	this.background.autoScroll(-80, 0);
	this.midgroundImage.autoScroll(-80, 0);

	// ship
	this.player = this.add.sprite(-10, 220, "volt");
	this.player.anchor.set(0, 0);
	this.player.animations.add("fly");
	this.player.play("fly", 12, true);
	this.player.smoothed = false;
	this.player.scale.set(0.75);
	// เสียง
	this.boom = this.add.audio("Boom");
	this.boom.allowMultiple = true;

	this.physics.enable(this.player, Phaser.Physics.ARCADE);
	this.player.body.collideWorldBounds = true;

	this.createWeapon();
	this.createEnemy();
	// คะแนน
	this.scoreText = this.add.text(32, 0, '' + this.game.score, {
		fill : 'white'
	});
	this.scoreText.z = 10;

	this.input.keyboard.addKeyCapture([

	Phaser.Keyboard.SPACEBAR, Phaser.Keyboard.X ]);
	this.player.inputEnabled = true;
	this.player.events.onInputDown.add(this.fireWeapon, this);

	this.player.maxHealth = 6;
	this.player.setHealth(3);

	this.player.canhit = true;

	this.heart = [];
	for (var i = 0; i < 3; i++) {
		this.heart[i] = this.add.sprite(300 - (32 * i), 10, "heart");
		this.heart[i].scale.set(1);

	}
	this.scoreText = this.add.text(32, 0, '' + this.game.score, {
		fill : 'blue'
	});
	this.scoreText.z = 10;
	this.player.events.onKilled.addOnce(this.onPlayerKilled, this);

};

Level3.prototype.update = function() {
	if (this.gameover)
		return;

	var spaceKey = this.game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
	if (spaceKey.isDown) {
		this.player.body.velocity.y = -300;
	} else {
		this.player.body.velocity.setTo(-10, 220);
		this.player.body.acceleration.setTo(-10, 220);
	}

	if (this.input.keyboard.isDown(Phaser.Keyboard.Z)) {
		this.fireWeapon();
	}
	this.enemy1.forEachAlive(function(a) {
		if (a.x == -10)
			a.x = this.world.height;
	}, this);
	this.physics.arcade.collide(this.enemy1, this.weapon1.bullets,
			this.onCollide1, null, this);
	this.physics.arcade.collide(this.enemy2, this.weapon1.bullets,
			this.onCollide2, null, this);
	if (this.player.canhit)
		this.physics.arcade.collide(this.enemy1, this.player,
				this.onPlayerCollide, null, this);
	if (this.player.canhit)
		this.physics.arcade.collide(this.enemy2, this.player,
				this.onPlayerCollide2, null, this);

	if (this.enemy1 && this.enemy2.countLiving() == 0) {
		this.gameover = true;
		win = this.add.text(this.world.centerX, this.world.centerY,
				"โลกปลอดภัย", {
					fill : 'Yellow'
				});
		win.anchor.set(0.5, 0.5);
		win.scale.set(0.1);
		var tw = this.add.tween(win.scale);
		tw.to({
			x : 2,
			y : 2
		}, 1000, "Linear", true, 0);

		delay = this.add.tween(win);
		delay.to({
			y : 100
		}, 1000, "Linear", true, 2000);
		tw.chain(delay);

		delay.onComplete.addOnce(this.quitGame, this);
		this.time.events.add(3000, this.quitGame, this);
		this.music.stop();

	}

};

Level3.prototype.onPlayerKilled = function() {
	this.gameover = true;
	win = this.add.text(this.world.centerX, this.world.centerY, "คุณแพ้แล้ว", {
		fill : 'Yellow'
	});
	win.anchor.set(0.5, 0.5);
	win.scale.set(0.1);
	var tw = this.add.tween(win.scale);
	tw.to({
		x : 2,
		y : 2
	}, 1000, "Linear", true, 0);
	delay = this.add.tween(win);
	delay.to({
		y : 100
	}, 1000, "Linear", true, 2000);
	tw.chain(delay);
	delay.onComplete.addOnce(this.quitGame, this);
};

Level3.prototype.onPlayerCollide = function(player, enemy1) {
	player.damage(2);
	player.canhit = false;
	player.alpha = 0.1;
	var tw = this.add.tween(player);
	tw.to({
		alpha : 1
	}, 200, "Linear", true, 0, 5);
	tw.onComplete.addOnce(function() {
		this.alpha = 1;
		this.canhit = true;
	}, player);
	console.log("Player kill " + count);
	if (count == 0) {
		this.heart[2].kill();
		this.heart[1].kill();
		count++;
		console.log("Player kill " + count);
	} else if (count == 1) {
		this.heart[0].kill();
		count++;
		console.log("Player kill " + count);
	}

	return true;
};
Level3.prototype.onPlayerCollide2 = function(player, enemy2) {
	player.damage(1);
	player.canhit = false;
	player.alpha = 0.1;
	var tw = this.add.tween(player);
	tw.to({
		alpha : 1
	}, 200, "Linear", true, 0, 5);
	tw.onComplete.addOnce(function() {
		this.alpha = 1;
		this.canhit = true;
	}, player);
	console.log("Player kill " + count);
	if (count == 0) {
		this.heart[2].kill();
		count++;
		console.log("Player kill " + count);
	} else if (count == 1) {
		this.heart[1].kill();
		count++;
		console.log("Player kill " + count);
	} else if (count == 2) {
		this.heart[0].kill();

		console.log("Player kill " + count);
	}
	return true;
};

Level3.prototype.createWeapon = function() {
	this.weapon1 = this.add.weapon(10, "bullet", 6);
	this.weapon1.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
	this.weapon1.trackSprite(this.player, 80, 60);
	this.weapon1.bulletSpeed = 500;
	this.weapon1.fireAngle = 0;
	this.weapon1.rate = 600;

};

Level3.prototype.fireWeapon = function() {
	this.weapon1.fire();
};

Level3.prototype.createEnemy = function() {
	this.enemy1 = this.add.group(this.game.world, 'knight1', false, true,
			Phaser.Physics.ARCADE);
	this.enemy1.z = 100;
	this.enemy2 = this.add.group(this.game.world, 'bird', false, true,
			Phaser.Physics.ARCADE);
	this.enemy2.z = 100;
	this.enemy1.maxHealth = 5;
	a = this.enemy1.create(600, 270, "knight");
	a.anchor.set(0, 0);
	a.scale.set(0.75);
	a.scale.x = -1.5;
	a.animations.add("run").play(7, true);
	a.body.velocity.x = -70;
	for (i = 0; i < 10; i++) {
		b = this.enemy2.create(600, Math.random() * 300, "bird");
		b.animations.add("fly").play(12, true);
		b.anchor.set(0.5);
		b.body.velocity.x = -50;
		tw = this.add.tween(b);
		var nx = 20 + Math.random() * 300;
		var nt = Math.random() * 500;
		tw.to({
			y : nx
		}, 1000 + nt, "Sine", true, 0, Number.MAX_VALUE, true);

		tw = this.add.tween(b);
		tw.to({
			x : nx
		}, 1000 + nt, "Sine", true, 0, Number.MAX_VALUE, true);

	}

};

/*
 * 0Level.prototype.createEnemy2 = function() { this.enemy1 =
 * this.add.group(this.game.world, 'BDG', false, true, Phaser.Physics.ARCADE);
 * this.enemy1.z = 100; a = this.enemy1.create(600, 270, "BDG"); a.anchor.set(0,
 * 0); a.scale.set(0.75); a.scale.x = -1.5; a.animations.add("run").play(7,
 * true); a.body.velocity.x = -70; this.enemy2 = this.add.group(this.game.world,
 * 'bird', false, true, Phaser.Physics.ARCADE); this.enemy2.z = 100; for (i = 0;
 * i < 10; i++) { b = this.enemy2.create(600, Math.random() * 300, "bird");
 * b.animations.add("fly").play(12, true); b.anchor.set(0.5); b.body.velocity.x =
 * -50; tw = this.add.tween(b); var nx = 20 + Math.random() * 300; var nt =
 * Math.random() * 500; tw.to({ y : nx }, 1000 + nt, "Sine", true, 0,
 * Number.MAX_VALUE, true);
 * 
 * tw = this.add.tween(b); tw.to({ x : nx }, 1000 + nt, "Sine", true, 0,
 * Number.MAX_VALUE, true);
 *  } if (this.enemy1 && this.enemy2.countLiving() == 0) {
 * 
 * win = this.add.text(this.world.centerX, this.world.centerY, "โลกปลอดภัย " ,{
 * fill : 'Green' }); win.width =400; win.anchor.set(0.5,0.5);
 * 
 * this.time.events.add(3000, this.quiteGame, this); //
 * this.game.state.start("Menu"); }
 * 
 *  };
 */

Level3.prototype.onCollide1 = function(enemy1, bullet) {
	enemy1.damage(1);
	bullet.kill();
	this.game.score = this.game.score + 10;
	this.scoreText.text = '' + this.game.score;

	exp = this.add.sprite(enemy1.x, enemy1.y, "explosion");
	exp.anchor.set(0.5);
	exp.animations.add("all", null, 12, false).play().killOnComplete = true;

	this.boom.play();

};

Level3.prototype.onCollide2 = function(enemy2, bullet) {
	enemy2.kill();
	bullet.kill();
	this.game.score++;
	this.scoreText.text = '' + this.game.score;
	exp = this.add.sprite(enemy2.x, enemy2.y, "explosion");
	exp.anchor.set(0.5);
	exp.animations.add("all", null, 12, false).play().killOnComplete = true;

	this.boom.play();

};

Level3.prototype.quitGame = function() {
	this.game.stage.backgroundColor = "black";
	this.game.state.start("End");
};
Level3.prototype.nextGame = function() {
	this.game.stage.backgroundColor = "black";
	this.game.state.start("Level2");
};
