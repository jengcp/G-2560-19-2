/**
 *End state.
 */
function End () {
	Phaser.State.call(this);
}
/** @type Phaser.State */
var proto = Object.create(Phaser.State);
End.prototype = proto;

End.prototype.create = function() {
	this.music = this.sound.add("mus2", 1, true);
	this.music.play();
	
	this.sprite = this.add.sprite(this.world.centerX, this.world.centerY,
			"ed");
	this.sprite.anchor.set(0.5, 0.5);
	this.sprite.scale.set(0.5,0.5);
	this.time.events.add(3000,this.quitGame,this);
	
	this.music.stop();
};
End.prototype.quitGame = function() {
	this.game.stage.backgroundColor = "black";
	this.music.stop();
	this.game.state.start("Menu");
};